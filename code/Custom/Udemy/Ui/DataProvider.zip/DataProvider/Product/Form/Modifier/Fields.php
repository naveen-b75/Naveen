<?php

namespace Custom\Udemy\Ui\DataProvider\Product\Form\Modifier;

use Magento\Catalog\Model\Locator\LocatorInterface;
use Magento\Catalog\Ui\DataProvider\Product\Form\Modifier\AbstractModifier;
use Magento\Ui\Component\Form\Element\DataType\Date;
use Magento\Ui\Component\Form\Element\DataType\Text;
use Magento\Ui\Component\Form\Element\Input;
use Magento\Ui\Component\Form\Field;
use Magento\Ui\Component\Container;
use Magento\Catalog\Model\ProductFactory;
use Magento\Reports\Model\ResourceModel\Product\Sold\CollectionFactory;


class Fields extends AbstractModifier{

    private  $locator;

    protected $productFactoy;

    protected $request;

    protected $collectionFactory;

    public function __construct(LocatorInterface $locator,CollectionFactory $collectionFactory, \Magento\Framework\App\RequestInterface $request, ProductFactory $productFactory)
    {
        $this->locator=$locator;
        $this->productFactoy=$productFactory;
        $this->request=$request;
        $this->collectionFactory=$collectionFactory;
    }
    public function modifyData(array $data)
    {
        return $data;
    }
    public function modifyMeta(array $meta)
    {
        $meta = array_replace_recursive(
            $meta,
            [
                'sold' => [
                    'arguments' => [
                        'data' => [
                            'config' => [
                                'label' => __('Total Products Sold'),
                                'collapsible' => true,
                                'componentType' => \Magento\Ui\Component\Form\Fieldset::NAME,
                                'dataScope' => 'data.product',
                                'sortOrder' => 10
                            ],
                        ],
                    ],
                    'children' => $this->getFields()
                ],
            ]
        );
        return $meta;
    }
    protected function getFields()
    {
        return [
            'from'    => [
                'arguments' => [
                    'data' => [
                        'config' => [
                            'label'         => __('From'),
                            'componentType' => Field::NAME,
                            'formElement'   => Date::NAME,
                            'dataScope'     => 'from',
                            'dataType'      => Text::NAME,
                            'sortOrder'     => 10,
                        ],
                    ],
                ],
            ],
            'to' => [
                'arguments' => [
                    'data' => [
                        'config' => [
                            'label'         => __('To'),
                            'componentType' => Field::NAME,
                            'formElement'   => Date::NAME,
                            'dataScope'     => 'to',
                            'dataType'      => Text::NAME,
                            'sortOrder'     => 20
                        ],
                    ],
                ],
            ],
            'button'=>[
                'arguments'=>[
                    'data'=>[
                        'config'=>[
                            'formElement'=>Container::NAME,
                            'componentType'=>'button',
                            'component'=>'Magento_Ui/js/form/components/button',
                            'visible'=>'true',
                            'title'=>__('Get Result'),
                            'additionalClasses' => 'admin__field-small',
                            'href' => '#',
                            'actions' => [
                                [
                                    'targetName' => $this->getProductsSold(),
                                    'actionName' => 'save'
                                ]
                            ]
                        ]
                    ]
                ]
            ],
            'result' => [
                'arguments' => [
                    'data' => [
                        'config' => [
                            'label'         => __('Result'),
                            'componentType' => Field::NAME,
                            'formElement'   => Input::NAME,
                            'dataScope'     => 'result',
                            'value'         => $this->getProductsSold(),
                            'dataType'      => Text::NAME,
                            'sortOrder'     => 50
                        ],
                    ],
                ],
            ],
        ];
    }

    public function getProductsSold(){
        $request=$this->request->getParam('id');
        $productid=$this->productFactoy->create()->load($request);
        $from=$productid->getFrom();
        $fromDate='2022/11/22 00:00:00';
        $toDate='2022/11/25 23:59:59';
        $customDataField=$this->collectionFactory->create()->addOrderedQty($fromDate,$toDate,true)->addAttributeToFilter('product_id',$request)->getFirstItem();
       // return (int)$customDataField->getData('ordered_qty');
        var_dump($this->request->getParams());
        return $from;
    }


}
