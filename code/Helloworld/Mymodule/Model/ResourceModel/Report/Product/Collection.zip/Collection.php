<?php

namespace Helloworld\Mymodule\Model\ResourceModel\Report\Product;

/**
 * Class Collection
 * @package Helloworld\Mymodule\Model\ResourceModel\Report\Product
 */
class Collection extends \Magento\Sales\Model\ResourceModel\Report\Collection\AbstractCollection
{

    protected $_periodFormat;
    /**
     * @var string
     */
    protected $_aggregationTable = 'sales_order';

    /**
     * @var array
     */
    protected $_selectedColumns = [];

    /**
     * Collection constructor.
     * @param \Magento\Framework\Data\Collection\EntityFactory $entityFactory
     * @param \Psr\Log\LoggerInterface $logger
     * @param \Magento\Framework\Data\Collection\Db\FetchStrategyInterface $fetchStrategy
     * @param \Magento\Framework\Event\ManagerInterface $eventManager
     * @param \Magento\Sales\Model\ResourceModel\Report $resource
     * @param \Magento\Framework\DB\Adapter\AdapterInterface|null $connection
     */
    public function __construct(
        \Magento\Framework\Data\Collection\EntityFactory $entityFactory,
        \Psr\Log\LoggerInterface $logger,
        \Magento\Framework\Data\Collection\Db\FetchStrategyInterface $fetchStrategy,
        \Magento\Framework\Event\ManagerInterface $eventManager,
        \Magento\Sales\Model\ResourceModel\Report $resource,
        \Magento\Framework\DB\Adapter\AdapterInterface $connection = null
    ) {
        $resource->init($this->_aggregationTable);
        parent::__construct($entityFactory, $logger, $fetchStrategy, $eventManager, $resource, $connection);
    }

    /**
     * @return array
     */
    protected function _getSelectedColumns()
    {
        $connection = $this->getConnection();
        if ('month' == $this->_period) {
            $this->_periodFormat = $connection->getDateFormatSql('created_at', '%Y-%m');
        } elseif ('year' == $this->_period) {
            $this->_periodFormat = $connection->getDateExtractSql(
                'period',
                \Magento\Framework\DB\Adapter\AdapterInterface::INTERVAL_YEAR
            );
        } else {
            $this->_periodFormat = $connection->getDateFormatSql('created_at', '%Y-%m-%d');
        }
        $this->_selectedColumns = [
            'increment_id' => 'increment_id',
            'creation_date' => 'created_at',
            'shipping_amount' => 'shipping_amount',
            'subtotal' => 'subtotal',
            'grand_total' => 'grand_total',
            'total_qty_ordered'=>'total_qty_ordered',

        ];

        return $this->_selectedColumns;
    }

    /**
     * @return \Magento\Sales\Model\ResourceModel\Report\Collection\AbstractCollection
     * @throws \Magento\Framework\Exception\LocalizedException
     */
    protected function _beforeLoad()
    {
        $this->getSelect()->from($this->getResource()->getMainTable(), $this->_getSelectedColumns());

        return parent::_beforeLoad();
    }

    /**
     * @return $this|\Magento\Sales\Model\ResourceModel\Report\Collection\AbstractCollection
     */
    protected function _applyDateRangeFilter()
    {
        if ($this->_from !== null) {
            $this->getSelect()->where($this->_aggregationTable.'.created_at >= ?', $this->_from);
        }
        if ($this->_to !== null) {
            $this->getSelect()->where($this->_aggregationTable.'.created_at <= ?', $this->_to);
        }

        return $this;
    }
}
