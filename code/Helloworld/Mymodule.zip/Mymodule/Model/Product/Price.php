<?php
namespace Helloworld\Mymodule\Model\Product;

class Price extends \Magento\Catalog\Model\Product\Type\Price{

}