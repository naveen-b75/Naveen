<?php
namespace Helloworld\Mymodule\Logger;

class Logger extends \Monolog\Logger{

}